<?php 

$pesquisar = $_REQUEST['pesquisar'] ?? '';

$avisos = $database->query(
query: "select * from avisos where titulo like :filtro or categoria like :filtro", 
class: Aviso::class, 
params: ['filtro' => "%$pesquisar%"])
->fetchAll(); // fetchAll retorna os valores em um array de objetos

view('index', compact('avisos'));


