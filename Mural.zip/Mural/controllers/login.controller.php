<?php

$mensagem = $_REQUEST['mensagem'] ?? '';

$_SESSION['mensagem'] = $mensagem;


view('login');