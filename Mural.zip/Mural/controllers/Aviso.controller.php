<?php

$aviso = $database->query(
    query: "select * from avisos where id = :id",
    class: Aviso::class,
    params: ['id' => $_GET['id']]
)->fetch(); 



view('index', compact('aviso'));
