<?php



if ($_SERVER['REQUEST_METHOD'] == 'POST') {

    
    


    $database->query( 


        query: "insert into avisos (titulo, categoria, descricao) values (:titulo, :categoria, :descricao)",

        params: [
            'titulo' => $_POST['titulo'],
            'categoria' => $_POST['categoria'],
            'descricao' => $_POST['descricao']
        ]

    );

        header('location: /index?mensagem=Registrado com sucesso!');


    exit();

};

view('cadastroAvisos');