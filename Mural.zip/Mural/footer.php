<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mural Comunitário</title>
</head>

<body>

    <footer class="bg-slate-200 shadow-sm border-t border-slate-300 mt-auto">
        <div class="container mx-auto px-4 py-4 text-center">
            <p class="text-slate-700">&copy; 2025 Mural Comunitário</p>
        </div>
    </footer>

</body>

</html>