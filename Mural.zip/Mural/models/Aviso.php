<?php


class Aviso
{

    public $id;
    public $titulo;
    public $categoria;
    public $descricao;
  


  
}

