<?php

class Usuario
{
    public $id;
    public $nome;
    public $email;
}
