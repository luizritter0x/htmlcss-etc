<?php


class validacaoAviso
{

    public $id;
    public $titulo;
    public $categoria;
    public $descricao;
    public $podePublicar;
  


  
}

