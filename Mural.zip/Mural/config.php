<?php

return [
    'database' => [
        'driver' => 'sqlite',
        'database' => 'bd.sqlite' 
    ]
];