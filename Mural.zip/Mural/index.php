<?php 


session_start();
require 'models/Aviso.php';
require 'models/Usuario.php';
require 'functions.php';
$config = require 'config.php';
require 'database.php';
require 'Validacao.php';
require 'routes.php';