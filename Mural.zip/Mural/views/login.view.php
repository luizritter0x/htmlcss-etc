<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="shortcut icon" href="Img/Arcade.png" type="image/x-icon">
    <script src="https://cdn.tailwindcss.com"></script>
    <title>Mural Comunitário</title>
</head>

<body class="bg-slate-50 min-h-screen flex items-start justify-center pt-12">

    <main class="w-full px-4 flex items-center justify-center">
        <div class="w-full max-w-md bg-white border border-slate-200 rounded-xl shadow-sm p-6 md:p-8">
            <div class="text-center mb-6">
                <h1 class="text-2xl font-bold text-slate-700">Entre na sua conta</h1>
            </div>

            <form class="space-y-4 md:space-y-6" method="post" action="/login">
                <div>
                    <label class="block text-sm md:text-md font-medium text-slate-700 mb-2">Email</label>
                    <input type="email" name="email" placeholder="example@exam.com"
                        class="w-full px-3 py-2 md:px-4 md:py-3 border border-slate-300 rounded-lg bg-white text-slate-800 focus:border-cyan-500 focus:outline-none">
                </div>

                <div>
                    <label class="block text-sm md:text-md font-medium text-slate-700 mb-2">Senha</label>
                    <input type="password" name="senha" placeholder="**********"
                        class="w-full px-3 py-2 md:px-4 md:py-3 border border-slate-300 rounded-lg bg-white text-slate-800 focus:border-cyan-500 focus:outline-none">
                </div>

                <button type="submit" class="w-full bg-slate-500 hover:bg-slate-600 text-white py-2 md:py-3 rounded-lg font-medium transition">
                    Entrar
                </button>
            </form>

        </div>
    </main>
                  
    
    <div class="mt-6 text-center text-sm text-slate-600">
        <span>Não tem uma conta? </span>
        <a href="/register" class="text-slate-500 hover:text-slate-700 font-medium">Registre-se aqui</a>



    <script src="script.js"></script>
</body>

</html>

<!DOCTYPE html>
<html lang="pt-br">

