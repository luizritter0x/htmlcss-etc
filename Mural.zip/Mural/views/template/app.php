<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mural Comunitário</title>
</head>
    <style>
        html, body {
            height: 100%;
            margin: 0;
            padding: 0;
        }
        body {
            display: flex;
            flex-direction: column;
        }
        main {
            flex: 1;
        }
        footer {
            margin-top: auto;
        }
    </style>
<body>

    <?php require 'header.php';?>


    <main>
        <?php require "views/{$view}.view.php"?>
    </main>

    <?php require 'footer.php';?>
</body>
</html>