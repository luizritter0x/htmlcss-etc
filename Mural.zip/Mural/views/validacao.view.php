<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src="https://cdn.tailwindcss.com"></script>
    <title>Mural Comunitário</title>
</head>

<body class="bg-slate-50 min-h-screen flex flex-col justify-between">
    <div class="flex flex-col flex-grow">
        

        <main class="flex-1 flex flex-col py-8">
            <div class="container mx-auto px-4">
                
                
                <?php if (empty($avisos)): ?>
                    <div class="flex justify-center items-center flex-col ">
                        <h1 class="md:text-3xl font-bold md:mt-24 text-center underline text-slate-800">Não há avisos registrados!</h1>
                        <a href="/cadastroAvisos" class="text-1xl mt-16 text-slate-500 underline pl-2 justify-center w-32 hover:text-slate-700 transition-colors">Crie um aviso.</a>
                    </div>
                <?php else: ?>

                <div class="w-full grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
                    
                        <?php foreach ($avisos as $aviso): ?>
                            <div class="bg-white border-l-4 border-slate-500 rounded-lg shadow-sm hover:shadow-md transition-all duration-200 border border-slate-200">
                                <div class="p-5">
                                    <div class="flex justify-between items-start mb-4">
                                        <h2 class="text-xl font-bold text-slate-700"><?= $aviso->titulo; ?></h2>
                                        <span class="px-3 py-1 bg-slate-50 text-slate-700 text-sm font-medium rounded-full border border-slate-200">
                                            <?= $aviso->categoria; ?>
                                        </span>
                                    </div>
                                    <div class="border-t border-slate-100 pt-4 h-32">
                                        <p class="text-slate-700 text-base leading-relaxed">
                                            <?= $aviso->descricao; ?>
                                        </p>
                                    </div>
                                    <div class="mt-4 flex justify-between items-center text-sm text-slate-600">

                                        <button class="text-slate-500 hover:text-slate-700 font-medium">
                                            Publicar
                                        </button>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    
                </div>
                <?php endif;?>
            </div>
        </main>
    </div>



    <script src="script.js"></script>
</body>

</html>