<div style="text-align: center; padding: 60px 20px; background-color: #f8fafc; min-height: 70vh; display:flex; flex-direction:column; justify-content:center; align-items:center;">
    <h1 style="font-size:72px; color:#334155; margin:0;">404</h1>
    <p style="font-size:24px; color:#475569; margin:20px 0;">Página não encontrada</p>
    <p style="font-size:16px; color:#6b7280; margin-bottom:40px; max-width:720px;">
        A página que você está procurando não existe ou foi movida.
    </p>
    <a href="/" style="
        display:inline-block;
        background-color:#64748b;
        color:white;
        padding:12px 32px;
        border-radius:6px;
        text-decoration:none;
        font-weight:bold;
        transition:background-color 0.2s;
    " onmouseover="this.style.backgroundColor='#475569'" onmouseout="this.style.backgroundColor='#64748b'">
        ← Voltar ao Início
    </a>
</div>
