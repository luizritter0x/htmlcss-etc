<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    
    <script src="https://cdn.tailwindcss.com"></script>
    <title>Mural Comunitário</title>
</head>

<body class="bg-slate-50 min-h-screen flex items-start justify-center pt-12">

    <main class="w-full px-4 flex items-center justify-center">
        <div class="w-full max-w-lg bg-white border border-slate-200 rounded-xl shadow-sm p-6 md:p-8">
            <form class="space-y-4 md:space-y-6" method="post" action="/cadastroAvisos">
                <div>
                    <label class="block text-sm md:text-md font-bold text-slate-700 mb-2">Título</label>
                    <input type="text" name="titulo"
                        class="w-full px-3 py-2 md:px-4 md:py-3 border border-slate-300 rounded-lg bg-white text-slate-800 font-medium">
                </div>

                <!-- <div>
                    <label class="block text-sm md:text-md font-bold text-green-900 mb-2">Categoria</label>
                    <input type="text" name="categoria"
                        class="w-full px-3 py-2 md:px-4 md:py-3 border border-green-900 rounded-lg text-green-900 font-bold"
                        placeholder="Segurança/Eventos/Vagas...">
                </div> -->
                <div>
                    <label class="block text-sm md:text-md font-bold text-slate-700 mb-2">Categoria</label>
                    <select name="categoria"
                        class="w-full px-3 py-2 md:px-4 md:py-3 border border-slate-300 rounded-lg bg-white text-slate-800 font-medium">
                        <option value="Segurança">Segurança</option>
                        <option value="Eventos">Eventos</option>
                        <option value="Vagas">Vagas</option>
                        <option value="Comunicados">Comunicados</option>
                        <option value="Outros">Outros</option>
                    </select>

                <div>
                    <label class="block text-sm md:text-md font-bold text-slate-700 mb-2">Descrição</label>
                    <textarea name="descricao" rows="5"
                        class="w-full px-3 py-2 md:px-4 md:py-3 border border-slate-300 rounded-lg bg-white text-slate-800 font-medium resize-none"
                        placeholder="Descrição do aviso"></textarea>
                </div>

                <div class="flex space-x-2">
                    <button type="reset"
                        class="flex-1 bg-white text-slate-700 border border-slate-300 py-2 md:py-3 px-4 rounded-lg font-medium transition hover:bg-slate-50">Cancelar</button>
                    <button type="submit"
                        class="flex-1 bg-slate-500 hover:bg-slate-600 text-white py-2 md:py-3 px-4 rounded-lg font-medium transition">Criar aviso</button>
                </div>
            </form>
        </div>
    </main>

    <script src="script.js"></script>
</body>

</html>