
var botao = document.getElementById('botao')


botao.addEventListener('click', () => {
    alert('Função indisponivel no momento!')
})



