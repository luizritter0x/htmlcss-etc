<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src="https://cdn.tailwindcss.com"></script>
    <title>Mural Comunitário</title>
</head>

<body class="bg-slate-300">

    <header class="bg-slate-200 shadow-sm border-b border-slate-300">
        <div class="max-w-7xl mx-auto px-4 py-4">
            <div class="grid grid-cols-1 sm:grid-cols-3 items-center gap-4">
                <div class="sm:text-left">
                    <a href="index" class="text-3xl font-bold text-slate-700">Mural Comunitário</a>
                </div>

                <nav class="hidden sm:flex justify-center space-x-8 text-lg md:text-xl font-semibold text-slate-700 tracking-wide">
                    <a href="index" class="transition hover:scale-105 hover:text-slate-900">Início</a>
                    <a href="cadastroAvisos" class="transition hover:scale-105 hover:text-slate-900">Criar Avisos</a>
                    <a href="login" class="transition hover:scale-105 hover:text-slate-900">Login</a>
                </nav>

                <div class="flex justify-end">
                    <form method="POST" action="index" class="flex flex-col md:flex-row items-center gap-3 w-full sm:w-auto">
                        <input
                            type="text"
                            name="pesquisar"
                            placeholder="Pesquisar avisos..."
                            class="px-4 py-2 rounded-xl border border-slate-300 bg-white placeholder:text-slate-400 text-slate-700 focus:outline-none focus:ring-2 focus:ring-slate-200 w-full sm:w-72 shadow-sm transition">
                        <button
                            type="submit"
                            class="bg-slate-500 text-white px-5 py-2 rounded-xl font-bold hover:bg-slate-600 active:scale-95 border border-slate-500 shadow-sm transition w-full sm:w-auto">
                            Buscar
                        </button>
                    </form>
                </div>
            </div>

        </div>
    </header>

</body>

</html>